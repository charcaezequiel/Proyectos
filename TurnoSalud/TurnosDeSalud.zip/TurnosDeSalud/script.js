// Configurar fecha mínima para reservas
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date();
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            const fechaInput = document.getElementById('fecha');
            if (fechaInput) {
                fechaInput.min = tomorrow.toISOString().split('T')[0];
            }
        });

        // Estado de la aplicación
        let isLoggedIn = false;
        let currentInterface = 'login';

        function showInterface(interfaceName) {
            // Ocultar todas las interfaces
            document.querySelectorAll('.interface-card').forEach(card => {
                card.classList.remove('active');
            });
            
            // Mostrar la interfaz seleccionada
            document.getElementById(interfaceName).classList.add('active');
            currentInterface = interfaceName;
            
            // Actualizar botones de navegación
            document.querySelectorAll('.nav-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            if (interfaceName !== 'login' && interfaceName !== 'register') {
                const activeBtn = document.querySelector(`[onclick="showInterface('${interfaceName}')"]`);
                if (activeBtn) {
                    activeBtn.classList.add('active');
                }
            }
        }

        function handleLogin(event) {
            event.preventDefault();
            
            // Simular autenticación
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            if (email && password) {
                isLoggedIn = true;
                document.getElementById('userInfo').style.display = 'flex';
                document.getElementById('navButtons').style.display = 'flex';
                showInterface('dashboard');
                
                // Mostrar mensaje de éxito
                alert('¡Inicio de sesión exitoso! Bienvenido a TurnoSalud CABA.');
            }
        }

        function handleRegister(event) {
            event.preventDefault();
            
            const password = document.getElementById('password-reg').value;
            const confirmPassword = document.getElementById('password-confirm').value;
            
            if (password !== confirmPassword) {
                alert('Las contraseñas no coinciden');
                return;
            }
            
            if (password.length < 6) {
                alert('La contraseña debe tener al menos 6 caracteres');
                return;
            }
            
            // Simular registro exitoso
            alert('¡Cuenta creada exitosamente! Ahora puedes iniciar sesión.');
            showInterface('login');
        }

        function handleReserva(event) {
            event.preventDefault();
            
            const especialidad = document.getElementById('especialidad').value;
            const centro = document.getElementById('centro').value;
            const medico = document.getElementById('medico').value;
            const fecha = document.getElementById('fecha').value;
            const horario = document.getElementById('horario').value;
            
            if (especialidad && centro && medico && fecha && horario) {
                alert('¡Turno reservado exitosamente! Recibirás una confirmación por email.');
                
                // Limpiar formulario
                event.target.reset();
                
                // Ir a mis turnos
                showInterface('turnos');
            }
        }

        function handleProfileUpdate(event) {
            event.preventDefault();
            alert('¡Información actualizada correctamente!');
        }

        function handlePasswordChange(event) {
            event.preventDefault();
            
            const newPassword = document.getElementById('new-password').value;
            const confirmPassword = document.getElementById('confirm-new-password').value;
            
            if (newPassword !== confirmPassword) {
                alert('Las contraseñas no coinciden');
                return;
            }
            
            if (newPassword.length < 6) {
                alert('La contraseña debe tener al menos 6 caracteres');
                return;
            }
            
            alert('¡Contraseña cambiada exitosamente!');
            event.target.reset();
        }

        function updateDoctors() {
            const especialidad = document.getElementById('especialidad').value;
            const medicoSelect = document.getElementById('medico');
            
            // Limpiar opciones anteriores
            medicoSelect.innerHTML = '<option value="">Selecciona un médico</option>';
            
            const doctores = {
                cardiologia: [
                    'Dr. Carlos Mendoza',
                    'Dra. Ana Martinez',
                    'Dr. Roberto Silva'
                ],
                dermatologia: [
                    'Dra. María González',
                    'Dr. Luis Fernández',
                    'Dra. Carmen López'
                ],
                ginecologia: [
                    'Dra. Patricia Ruiz',
                    'Dra. Elena Morales',
                    'Dr. Miguel Santos'
                ],
                neurologia: [
                    'Dr. Fernando Castro',
                    'Dra. Isabel Herrera',
                    'Dr. Andrés Vega'
                ],
                pediatria: [
                    'Dra. Lucía Ramírez',
                    'Dr. Pablo Jiménez',
                    'Dra. Rosa Díaz'
                ],
                traumatologia: [
                    'Dr. Sergio Ortega',
                    'Dra. Mónica Vargas',
                    'Dr. Daniel Torres'
                ],
                clinica: [
                    'Dr. Alberto Pérez',
                    'Dra. Cristina Soto',
                    'Dr. Javier Campos'
                ]
            };
            
            if (doctores[especialidad]) {
                doctores[especialidad].forEach(doctor => {
                    const option = document.createElement('option');
                    option.value = doctor.toLowerCase().replace(/\s+/g, '-');
                    option.textContent = doctor;
                    medicoSelect.appendChild(option);
                });
            }
        }

        function filterTurnos(status) {
            const turnos = document.querySelectorAll('.turno-item');
            const filterBtns = document.querySelectorAll('.filter-btn');
            
            // Actualizar botones
            filterBtns.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            // Filtrar turnos
            turnos.forEach(turno => {
                if (status === 'todos') {
                    turno.style.display = 'block';
                } else {
                    const turnoStatus = turno.dataset.status;
                    turno.style.display = turnoStatus === status ? 'block' : 'none';
                }
            });
        }

        function filterCentros(type) {
            const centros = document.querySelectorAll('.centro-item');
            const filterBtns = document.querySelectorAll('.filter-btn');
            
            // Actualizar botones
            filterBtns.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            // Filtrar centros
            centros.forEach(centro => {
                if (type === 'todos') {
                    centro.style.display = 'block';
                } else {
                    const centroType = centro.dataset.type;
                    centro.style.display = centroType === type ? 'block' : 'none';
                }
            });
        }

        function logout() {
            isLoggedIn = false;
            document.getElementById('userInfo').style.display = 'none';
            document.getElementById('navButtons').style.display = 'none';
            showInterface('login');
            
            // Limpiar formularios
            document.querySelectorAll('form').forEach(form => form.reset());
        }

        // Efectos para los interruptores de preferencias
        document.addEventListener('DOMContentLoaded', function() {
            const toggles = document.querySelectorAll('input[type="checkbox"]');
            toggles.forEach(toggle => {
                toggle.addEventListener('change', function() {
                    const slider = this.nextElementSibling;
                    const knob = slider.nextElementSibling;
                    
                    if (this.checked) {
                        slider.style.backgroundColor = '#4285f4';
                        knob.style.transform = 'translateX(26px)';
                    } else {
                        slider.style.backgroundColor = '#ccc';
                        knob.style.transform = 'translateX(0px)';
                    }
                });
            });
        });
