// auth.js - Manejo de autenticación

// Simulación de base de datos de usuarios (en aplicación real esto estaría en el backend)
let users = JSON.parse(localStorage.getItem('cointrol_users')) || [];

// Función para registrar usuario
function registerUser(name, email, password) {
    // Verificar si el email ya existe
    if (users.find(user => user.email === email)) {
        return { success: false, message: 'Este email ya está registrado' };
    }

    // Crear nuevo usuario
    const newUser = {
        id: Date.now(),
        name: name,
        email: email,
        password: password, // En producción, esto debería estar hasheado
        createdAt: new Date().toISOString(),
        transactions: [],
        totalIncome: 0,
        totalExpense: 0
    };

    users.push(newUser);
    localStorage.setItem('cointrol_users', JSON.stringify(users));
    
    return { success: true, message: 'Usuario registrado exitosamente' };
}

// Función para iniciar sesión
function loginUser(email, password) {
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        // Guardar sesión del usuario
        const userSession = {
            id: user.id,
            name: user.name,
            email: user.email,
            createdAt: user.createdAt
        };
        localStorage.setItem('cointrol_session', JSON.stringify(userSession));
        return { success: true, message: 'Inicio de sesión exitoso' };
    }
    
    return { success: false, message: 'Email o contraseña incorrectos' };
}

// Función para cerrar sesión
function logoutUser() {
    localStorage.removeItem('cointrol_session');
    window.location.href = 'index.html';
}

// Función para verificar si hay sesión activa
function checkSession() {
    const session = localStorage.getItem('cointrol_session');
    return session ? JSON.parse(session) : null;
}

// Función para obtener el usuario actual completo
function getCurrentUser() {
    const session = checkSession();
    if (!session) return null;
    
    users = JSON.parse(localStorage.getItem('cointrol_users')) || [];
    return users.find(u => u.id === session.id);
}

// Función para actualizar usuario
function updateUser(userId, updatedData) {
    users = JSON.parse(localStorage.getItem('cointrol_users')) || [];
    const index = users.findIndex(u => u.id === userId);
    
    if (index !== -1) {
        users[index] = { ...users[index], ...updatedData };
        localStorage.setItem('cointrol_users', JSON.stringify(users));
        
        // Actualizar sesión si se cambió el nombre o email
        const session = checkSession();
        if (session && session.id === userId) {
            session.name = updatedData.name || session.name;
            session.email = updatedData.email || session.email;
            localStorage.setItem('cointrol_session', JSON.stringify(session));
        }
        
        return { success: true, message: 'Perfil actualizado exitosamente' };
    }
    
    return { success: false, message: 'Error al actualizar el perfil' };
}

// Función para cambiar contraseña
function changePassword(userId, currentPassword, newPassword) {
    users = JSON.parse(localStorage.getItem('cointrol_users')) || [];
    const user = users.find(u => u.id === userId);
    
    if (!user) {
        return { success: false, message: 'Usuario no encontrado' };
    }
    
    if (user.password !== currentPassword) {
        return { success: false, message: 'Contraseña actual incorrecta' };
    }
    
    user.password = newPassword;
    localStorage.setItem('cointrol_users', JSON.stringify(users));
    
    return { success: true, message: 'Contraseña cambiada exitosamente' };
}

// Función para eliminar cuenta
function deleteAccount(userId) {
    users = JSON.parse(localStorage.getItem('cointrol_users')) || [];
    users = users.filter(u => u.id !== userId);
    localStorage.setItem('cointrol_users', JSON.stringify(users));
    logoutUser();
}

// Proteger páginas que requieren autenticación
function protectPage() {
    const session = checkSession();
    const currentPage = window.location.pathname.split('/').pop();
    
    // Si estamos en una página protegida y no hay sesión, redirigir a login
    if ((currentPage === 'dashboard.html' || currentPage === 'profile.html') && !session) {
        window.location.href = 'login.html';
    }
    
    // Si estamos en login o register y ya hay sesión, redirigir a dashboard
    if ((currentPage === 'login.html' || currentPage === 'register.html') && session) {
        window.location.href = 'dashboard.html';
    }
}

// Event Listeners para formularios
document.addEventListener('DOMContentLoaded', function() {
    protectPage();
    
    // Formulario de registro
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const terms = document.getElementById('terms').checked;
            
            const errorMessage = document.getElementById('errorMessage');
            const successMessage = document.getElementById('successMessage');
            
            // Limpiar mensajes
            errorMessage.classList.remove('show');
            successMessage.classList.remove('show');
            
            // Validaciones
            if (password !== confirmPassword) {
                errorMessage.textContent = 'Las contraseñas no coinciden';
                errorMessage.classList.add('show');
                return;
            }
            
            if (!terms) {
                errorMessage.textContent = 'Debes aceptar los términos y condiciones';
                errorMessage.classList.add('show');
                return;
            }
            
            const result = registerUser(name, email, password);
            
            if (result.success) {
                successMessage.textContent = result.message + '. Redirigiendo...';
                successMessage.classList.add('show');
                
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 2000);
            } else {
                errorMessage.textContent = result.message;
                errorMessage.classList.add('show');
            }
        });
    }
    
    // Formulario de login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            const errorMessage = document.getElementById('errorMessage');
            errorMessage.classList.remove('show');
            
            const result = loginUser(email, password);
            
            if (result.success) {
                window.location.href = 'dashboard.html';
            } else {
                errorMessage.textContent = result.message;
                errorMessage.classList.add('show');
            }
        });
    }
    
    // Botón de cerrar sesión
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
                logoutUser();
            }
        });
    }
});