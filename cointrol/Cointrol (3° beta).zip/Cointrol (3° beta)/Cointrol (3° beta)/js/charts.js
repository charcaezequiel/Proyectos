// charts.js - Manejo de gráficos con Google Charts

// Cargar Google Charts
google.charts.load('current', {'packages':['corechart']});

// Función para generar gráfico de gastos por categoría
function loadCategoryChart() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;

    // Filtrar solo gastos
    const expenses = currentUser.transactions.filter(t => t.type === 'expense');
    
    if (expenses.length === 0) {
        document.getElementById('categoryChart').innerHTML = '';
        document.getElementById('categoryChartInfo').style.display = 'block';
        return;
    }

    document.getElementById('categoryChartInfo').style.display = 'none';

    // Agrupar gastos por categoría
    const categoryData = {};
    expenses.forEach(transaction => {
        const category = transaction.category;
        categoryData[category] = (categoryData[category] || 0) + transaction.amount;
    });

    // Preparar datos para Google Charts
    const chartData = [['Categoría', 'Monto']];
    Object.keys(categoryData).forEach(category => {
        chartData.push([category, categoryData[category]]);
    });

    // Crear el gráfico
    const data = google.visualization.arrayToDataTable(chartData);

    const options = {
        title: 'Distribución de Gastos',
        width: '100%',
        height: 400,
        pieHole: 0.4,
        colors: ['#e74c3c', '#3498db', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c', '#34495e'],
        legend: { position: 'bottom' },
        chartArea: { width: '90%', height: '75%' },
        pieSliceText: 'percentage',
        tooltip: { 
            text: 'both',
            trigger: 'selection'
        }
    };

    const chart = new google.visualization.PieChart(document.getElementById('categoryChart'));
    chart.draw(data, options);
}

// Función para generar gráfico mensual de ingresos vs gastos
function loadMonthlyChart() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;

    if (currentUser.transactions.length === 0) {
        document.getElementById('monthlyChart').innerHTML = '';
        document.getElementById('monthlyChartInfo').style.display = 'block';
        return;
    }

    document.getElementById('monthlyChartInfo').style.display = 'none';

    // Obtener el año actual
    const currentYear = new Date().getFullYear();

    // Inicializar datos mensuales
    const monthlyData = {};
    const monthNames = [
        'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];

    // Inicializar cada mes con 0
    monthNames.forEach((month, index) => {
        monthlyData[index] = { income: 0, expense: 0 };
    });

    // Agrupar transacciones por mes
    currentUser.transactions.forEach(transaction => {
        const date = new Date(transaction.date);
        if (date.getFullYear() === currentYear) {
            const month = date.getMonth();
            if (transaction.type === 'income') {
                monthlyData[month].income += transaction.amount;
            } else {
                monthlyData[month].expense += transaction.amount;
            }
        }
    });

    // Preparar datos para Google Charts
    const chartData = [['Mes', 'Ingresos', 'Gastos']];
    monthNames.forEach((month, index) => {
        chartData.push([
            month,
            monthlyData[index].income,
            monthlyData[index].expense
        ]);
    });

    // Crear el gráfico
    const data = google.visualization.arrayToDataTable(chartData);

    const options = {
        title: `Ingresos vs Gastos - ${currentYear}`,
        width: '100%',
        height: 400,
        colors: ['#27ae60', '#e74c3c'],
        legend: { position: 'bottom' },
        chartArea: { width: '85%', height: '70%' },
        vAxis: {
            title: 'Monto ($)',
            minValue: 0,
            format: '$#,###'
        },
        hAxis: {
            title: 'Mes',
            slantedText: true,
            slantedTextAngle: 45
        },
        bar: { groupWidth: '75%' },
        isStacked: false
    };

    const chart = new google.visualization.ColumnChart(document.getElementById('monthlyChart'));
    chart.draw(data, options);
}

// Función para cargar todos los gráficos
function loadAllCharts() {
    google.charts.setOnLoadCallback(function() {
        loadCategoryChart();
        loadMonthlyChart();
    });
}

// Función para actualizar gráficos después de agregar/eliminar transacciones
function updateCharts() {
    loadCategoryChart();
    loadMonthlyChart();
}

// Redimensionar gráficos cuando cambia el tamaño de la ventana
window.addEventListener('resize', function() {
    if (document.getElementById('categoryChart')) {
        loadAllCharts();
    }
});

// Inicializar gráficos cuando se carga la página
document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('dashboard.html')) {
        // Esperar a que Google Charts esté listo
        google.charts.setOnLoadCallback(function() {
            loadAllCharts();
        });
    }
});