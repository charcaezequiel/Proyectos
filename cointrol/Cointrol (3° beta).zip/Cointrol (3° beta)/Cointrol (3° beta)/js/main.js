// main.js - Funciones generales y utilidades

// Función para formatear números como moneda
function formatCurrency(amount) {
    return new Intl.NumberFormat('es-AR', {
        style: 'currency',
        currency: 'ARS'
    }).format(amount);
}

// Función para validar email
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Función para capitalizar primera letra
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Función para obtener el saludo según la hora del día
function getGreeting() {
    const hour = new Date().getHours();
    
    if (hour < 12) {
        return 'Buenos días';
    } else if (hour < 20) {
        return 'Buenas tardes';
    } else {
        return 'Buenas noches';
    }
}

// Función para mostrar notificaciones (opcional)
function showNotification(message, type = 'info') {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Estilos inline para la notificación
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background-color: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        z-index: 10000;
        animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    // Eliminar después de 3 segundos
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Animaciones para notificaciones
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Función para exportar datos a JSON
function exportDataToJSON() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const dataStr = JSON.stringify(currentUser, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `cointrol_backup_${new Date().toISOString().split('T')[0]}.json`;
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

// Función para calcular estadísticas del mes actual
function getCurrentMonthStats() {
    const currentUser = getCurrentUser();
    if (!currentUser) return null;
    
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    
    const monthTransactions = currentUser.transactions.filter(t => {
        const transDate = new Date(t.date);
        return transDate.getMonth() === currentMonth && transDate.getFullYear() === currentYear;
    });
    
    const monthIncome = monthTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
    
    const monthExpense = monthTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
    
    return {
        transactions: monthTransactions.length,
        income: monthIncome,
        expense: monthExpense,
        balance: monthIncome - monthExpense
    };
}

// Función para obtener las categorías más usadas
function getTopCategories(type = 'expense', limit = 5) {
    const currentUser = getCurrentUser();
    if (!currentUser) return [];
    
    const categories = {};
    
    currentUser.transactions
        .filter(t => t.type === type)
        .forEach(t => {
            categories[t.category] = (categories[t.category] || 0) + t.amount;
        });
    
    return Object.entries(categories)
        .sort((a, b) => b[1] - a[1])
        .slice(0, limit)
        .map(([category, amount]) => ({ category, amount }));
}

// Función para detectar si es dispositivo móvil
function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// Función para scroll suave
function smoothScroll(target) {
    const element = document.querySelector(target);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Inicialización general
document.addEventListener('DOMContentLoaded', function() {
    // Agregar clase para dispositivos móviles
    if (isMobileDevice()) {
        document.body.classList.add('mobile-device');
    }
    
    // Manejar enlaces de navegación suave (si existen)
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            smoothScroll(this.getAttribute('href'));
        });
    });
    
    // Actualizar año en el footer
    const footerYear = document.querySelector('footer p');
    if (footerYear) {
        footerYear.innerHTML = footerYear.innerHTML.replace('2025', new Date().getFullYear());
    }
    
    // Log de bienvenida en consola
    console.log('%cCointrol App', 'color: #4a90e2; font-size: 24px; font-weight: bold;');
    console.log('%c¡Controla tus finanzas de manera inteligente!', 'color: #7f8c8d; font-size: 14px;');
});

// Manejo de errores global
window.addEventListener('error', function(e) {
    console.error('Error global capturado:', e.error);
});

// Advertencia antes de cerrar si hay cambios sin guardar
let hasUnsavedChanges = false;

window.addEventListener('beforeunload', function(e) {
    if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
        return '';
    }
});