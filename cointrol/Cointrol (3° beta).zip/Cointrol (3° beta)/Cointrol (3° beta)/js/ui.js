// ui.js - Manejo de interfaz de usuario para Dashboard y Profile

// Función para agregar transacción
function addTransaction(type, description, amount, category, date) {
    const currentUser = getCurrentUser();
    if (!currentUser) return { success: false, message: 'Usuario no encontrado' };
    
    const transaction = {
        id: Date.now(),
        type: type, // 'income' o 'expense'
        description: description,
        amount: parseFloat(amount),
        category: category,
        date: date,
        createdAt: new Date().toISOString()
    };
    
    currentUser.transactions.push(transaction);
    
    // Actualizar totales
    if (type === 'income') {
        currentUser.totalIncome += transaction.amount;
    } else {
        currentUser.totalExpense += transaction.amount;
    }
    
    updateUser(currentUser.id, {
        transactions: currentUser.transactions,
        totalIncome: currentUser.totalIncome,
        totalExpense: currentUser.totalExpense
    });
    
    return { success: true, message: 'Transacción agregada exitosamente' };
}

// Función para eliminar transacción
function deleteTransaction(transactionId) {
    const currentUser = getCurrentUser();
    if (!currentUser) return { success: false };
    
    const transaction = currentUser.transactions.find(t => t.id === transactionId);
    if (!transaction) return { success: false };
    
    // Restar del total
    if (transaction.type === 'income') {
        currentUser.totalIncome -= transaction.amount;
    } else {
        currentUser.totalExpense -= transaction.amount;
    }
    
    // Eliminar transacción
    currentUser.transactions = currentUser.transactions.filter(t => t.id !== transactionId);
    
    updateUser(currentUser.id, {
        transactions: currentUser.transactions,
        totalIncome: currentUser.totalIncome,
        totalExpense: currentUser.totalExpense
    });
    
    return { success: true };
}

// Función para cargar y mostrar el dashboard
function loadDashboard() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    // Mostrar nombre del usuario
    document.getElementById('userName').textContent = currentUser.name;
    
    // Mostrar fecha actual
    const today = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('currentDate').textContent = today.toLocaleDateString('es-ES', options);
    
    // Mostrar totales
    document.getElementById('totalIncome').textContent = `$${currentUser.totalIncome.toFixed(2)}`;
    document.getElementById('totalExpense').textContent = `$${currentUser.totalExpense.toFixed(2)}`;
    
    const balance = currentUser.totalIncome - currentUser.totalExpense;
    const balanceElement = document.getElementById('balance');
    balanceElement.textContent = `$${balance.toFixed(2)}`;
    balanceElement.style.color = balance >= 0 ? 'var(--success-color)' : 'var(--danger-color)';
    
    // Mostrar transacciones
    displayTransactions(currentUser.transactions);
    
    // Actualizar gráficos si la función existe
    if (typeof updateCharts === 'function') {
        updateCharts();
    }
}

// Función para mostrar transacciones
function displayTransactions(transactions) {
    const transactionList = document.getElementById('transactionList');
    
    if (transactions.length === 0) {
        transactionList.innerHTML = '<p class="no-transactions">No hay transacciones registradas</p>';
        return;
    }
    
    // Ordenar por fecha (más reciente primero)
    const sortedTransactions = transactions.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    transactionList.innerHTML = sortedTransactions.map(t => `
        <div class="transaction-item">
            <div class="transaction-details">
                <div class="transaction-description">${t.description}</div>
                <div class="transaction-meta">
                    <span class="transaction-category">${t.category}</span>
                    <span>${new Date(t.date).toLocaleDateString('es-ES')}</span>
                </div>
            </div>
            <span class="transaction-amount ${t.type}">
                ${t.type === 'income' ? '+' : '-'}$${t.amount.toFixed(2)}
            </span>
            <button class="transaction-delete" onclick="handleDeleteTransaction(${t.id})">🗑️</button>
        </div>
    `).join('');
}

// Función para manejar eliminación de transacción
function handleDeleteTransaction(transactionId) {
    if (confirm('¿Estás seguro de que quieres eliminar esta transacción?')) {
        deleteTransaction(transactionId);
        loadDashboard();
    }
}

// Función para cargar perfil
function loadProfile() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    document.getElementById('profileName').textContent = currentUser.name;
    document.getElementById('profileEmail').textContent = currentUser.email;
    
    // Fecha de registro
    const memberSince = new Date(currentUser.createdAt).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    document.getElementById('memberSince').textContent = memberSince;
    
    // Estadísticas
    document.getElementById('totalTransactions').textContent = currentUser.transactions.length;
    
    const daysActive = Math.floor((Date.now() - new Date(currentUser.createdAt)) / (1000 * 60 * 60 * 24));
    document.getElementById('daysActive').textContent = daysActive;
    
    // Prellenar formulario de edición
    document.getElementById('editName').value = currentUser.name;
    document.getElementById('editEmail').value = currentUser.email;
}

// Event Listeners para Dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Cargar dashboard si estamos en esa página
    if (window.location.pathname.includes('dashboard.html')) {
        loadDashboard();
        
        // Modal
        const modal = document.getElementById('transactionModal');
        const addIncomeBtn = document.getElementById('addIncomeBtn');
        const addExpenseBtn = document.getElementById('addExpenseBtn');
        const closeModal = document.querySelector('.close');
        const transactionForm = document.getElementById('transactionForm');
        
        // Abrir modal para ingreso
        addIncomeBtn.addEventListener('click', function() {
            document.getElementById('modalTitle').textContent = 'Agregar Ingreso';
            document.getElementById('transactionType').value = 'income';
            document.getElementById('date').valueAsDate = new Date();
            modal.style.display = 'block';
        });
        
        // Abrir modal para gasto
        addExpenseBtn.addEventListener('click', function() {
            document.getElementById('modalTitle').textContent = 'Agregar Gasto';
            document.getElementById('transactionType').value = 'expense';
            document.getElementById('date').valueAsDate = new Date();
            modal.style.display = 'block';
        });
        
        // Cerrar modal
        closeModal.addEventListener('click', function() {
            modal.style.display = 'none';
            transactionForm.reset();
        });
        
        // Cerrar modal al hacer click fuera
        window.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.style.display = 'none';
                transactionForm.reset();
            }
        });
        
        // Enviar formulario de transacción
        transactionForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const type = document.getElementById('transactionType').value;
            const description = document.getElementById('description').value;
            const amount = document.getElementById('amount').value;
            const category = document.getElementById('category').value;
            const date = document.getElementById('date').value;
            
            const result = addTransaction(type, description, amount, category, date);
            
            if (result.success) {
                modal.style.display = 'none';
                transactionForm.reset();
                loadDashboard(); // Esto también actualizará los gráficos
            }
        });
    }
    
    // Cargar perfil si estamos en esa página
    if (window.location.pathname.includes('profile.html')) {
        loadProfile();
        
        // Formulario de editar perfil
        const profileForm = document.getElementById('profileForm');
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('editName').value;
            const email = document.getElementById('editEmail').value;
            
            const currentUser = getCurrentUser();
            const result = updateUser(currentUser.id, { name, email });
            
            const messageDiv = document.getElementById('profileMessage');
            messageDiv.textContent = result.message;
            messageDiv.classList.add('show');
            
            if (result.success) {
                loadProfile();
                setTimeout(() => {
                    messageDiv.classList.remove('show');
                }, 3000);
            }
        });
        
        // Formulario de cambiar contraseña
        const passwordForm = document.getElementById('passwordForm');
        passwordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPassword').value;
            const confirmNewPassword = document.getElementById('confirmNewPassword').value;
            
            const messageDiv = document.getElementById('passwordMessage');
            
            if (newPassword !== confirmNewPassword) {
                messageDiv.textContent = 'Las contraseñas no coinciden';
                messageDiv.classList.add('show');
                return;
            }
            
            const currentUser = getCurrentUser();
            const result = changePassword(currentUser.id, currentPassword, newPassword);
            
            messageDiv.textContent = result.message;
            messageDiv.classList.remove('error-message', 'success-message');
            messageDiv.classList.add(result.success ? 'success-message' : 'error-message');
            messageDiv.classList.add('show');
            
            if (result.success) {
                passwordForm.reset();
                setTimeout(() => {
                    messageDiv.classList.remove('show');
                }, 3000);
            }
        });
        
        // Botón de eliminar cuenta
        const deleteAccountBtn = document.getElementById('deleteAccountBtn');
        deleteAccountBtn.addEventListener('click', function() {
            if (confirm('⚠️ ADVERTENCIA: Esta acción es irreversible. ¿Estás seguro de que quieres eliminar tu cuenta y todos tus datos?')) {
                const currentUser = getCurrentUser();
                deleteAccount(currentUser.id);
            }
        });
    }
});